function getElectionData() {
    return JSON.parse(localStorage.getItem("electionData"));
  }
  
  async function renderTallies() {
    const talliesDiv = document.getElementById("tallies");
    talliesDiv.innerHTML = "Loading results...";
    await new Promise(res => setTimeout(res, 500)); // async delay
  
    const data = getElectionData();
    talliesDiv.innerHTML = "";
  
    for (const [position, candidates] of Object.entries(data.votes)) {
      const section = document.createElement("div");
      section.innerHTML = `<h2>${position.toUpperCase()}</h2>`;
      if (Object.keys(candidates).length === 0) {
        section.innerHTML += "<p>No votes yet.</p>";
      } else {
        for (const [candidate, count] of Object.entries(candidates)) {
          const p = document.createElement("p");
          p.textContent = `${candidate}: ${count}`;
          section.appendChild(p);
        }
      }
      talliesDiv.appendChild(section);
    }
  }
  
  document.getElementById("refreshBtn").addEventListener("click", renderTallies);
  
  window.addEventListener("storage", (event) => {
    if (event.key === "electionData") {
      renderTallies();
    }
  });
  
  renderTallies();
  