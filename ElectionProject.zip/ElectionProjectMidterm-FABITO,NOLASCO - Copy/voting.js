// Initialize storage if not set
function initStorage() {
    if (!localStorage.getItem("electionData")) {
      const data = {
        votedIds: [],
        votes: {
          president: {},
          vp: {},
          treasurer: {},
          secretary: {},
          pio: {}
        }
      };
      localStorage.setItem("electionData", JSON.stringify(data));
    }
  }
  
  function getElectionData() {
    return JSON.parse(localStorage.getItem("electionData"));
  }
  
  function saveElectionData(data) {
    localStorage.setItem("electionData", JSON.stringify(data));
  }
  
  document.getElementById("submitVote").addEventListener("click", () => {
    const message = document.getElementById("message");
    message.textContent = "";
    message.className = "";
  
    const userId = document.getElementById("userId").value.trim();
    if (!userId) {
      message.textContent = "Error: ID number is required.";
      message.className = "error";
      return;
    }
  
    let data = getElectionData();
    if (data.votedIds.includes(userId)) {
      message.textContent = "Error: This ID has already voted.";
      message.className = "error";
      return;
    }
  
    const positions = ["president", "vp", "treasurer", "secretary", "pio"];
    const selections = {};
  
    for (const pos of positions) {
      const choice = document.querySelector(`input[name="${pos}"]:checked`);
      if (!choice) {
        message.textContent = `Error: Please vote for ${pos}.`;
        message.className = "error";
        return;
      }
      selections[pos] = choice.value;
    }
  
    // Save votes
    for (const pos of positions) {
      if (!data.votes[pos][selections[pos]]) {
        data.votes[pos][selections[pos]] = 0;
      }
      data.votes[pos][selections[pos]]++;
    }
  
    data.votedIds.push(userId);
    saveElectionData(data);
  
    message.textContent = "Vote submitted successfully!";
    message.className = "success";
  
    // Reset form
    document.getElementById("userId").value = "";
    positions.forEach(pos => {
      const checked = document.querySelector(`input[name="${pos}"]:checked`);
      if (checked) checked.checked = false;
    });
  });
  
  initStorage();
  